# ArASL EDA Report



## Classes

Found **32** classes. Saved list to `classes.txt`.

**Class Counts** — saved CSV: `class_counts.csv`

**Preview (32 rows)**:

```
class,count
ain,1923
al,1341
aleff,1473
bb,1604
dal,1443
dha,1552
dhad,1483
fa,1766
gaaf,1516
ghain,1788
ha,1420
haa,1338
jeem,1362
kaaf,1588
khaa,1412
la,1559
laam,1644
meem,1577
nun,1648
ra,1470
saad,1702
seen,1449
sheen,1317
ta,1647
taa,1645
thaa,1573
thal,1391
toot,1602
waw,1197
ya,1516
yaa,1290
zay,1186

```

**Class Distribution (bar)**

![Class Distribution (bar)](class_distribution.png)

**Class Counts with Percentage** — saved CSV: `class_counts_with_percentage.csv`

**Preview (32 rows)**:

```
class,count,percentage
ain,1923,3.971335343438933
ghain,1788,3.692536450373797
fa,1766,3.647102556689108
saad,1702,3.5149312296063773
nun,1648,3.4034116723803227
ta,1647,3.4013464953946553
taa,1645,3.3972161414233195
laam,1644,3.395150964437652
bb,1604,3.3125438850109457
toot,1602,3.30841353103961
kaaf,1588,3.2795010532402626
meem,1577,3.256784106397918
thaa,1573,3.2485233984552475
la,1559,3.2196109206559
dha,1552,3.205154681756227
gaaf,1516,3.13080831027219
ya,1516,3.13080831027219
dhad,1483,3.062657469745157
aleff,1473,3.0420056998884806
ra,1470,3.0358101689314774
seen,1449,2.9924414522324563
dal,1443,2.9800503903184503
ha,1420,2.932551319648094
khaa,1412,2.916029903762752
thal,1391,2.8726611870637315
jeem,1362,2.812771054479369
al,1341,2.7694023377803476
haa,1338,2.7632068068233444
sheen,1317,2.7198380901243238
yaa,1290,2.6640783115112967
waw,1197,2.472016851844203
zay,1186,2.4492999050018587

```

**Class Balance (pie)**

![Class Balance (pie)](class_balance.png)

**Corrupted Images per Class** — saved CSV: `corrupted_counts_per_class.csv`

**Preview (32 rows)**:

```
class,corrupted
ain,0
al,0
yaa,0
ya,0
waw,0
toot,0
thal,0
thaa,0
taa,0
ta,0
sheen,0
seen,0
saad,0
ra,0
nun,0
meem,0
laam,0
la,0
khaa,0
kaaf,0
jeem,0
haa,0
ha,0
ghain,0
gaaf,0
fa,0
dhad,0
dha,0
dal,0
bb,0
aleff,0
zay,0

```


## Corrupted Summary

Total corrupted files: **0**

**Top classes by corrupted images**

![Top classes by corrupted images](corrupted_top10.png)

**Sample Grid**

![Sample Grid](sample_grid.png)


## Duplicates Summary

Total duplicate files (scanned): **0**


## Final Summary

- Classes: **32**
- Total images: **48422**
- Corrupted files: **0**
- Duplicates (scanned): **0**
- Outputs folder: `EDA_outputs`
- Report file: `eda_report.md`

